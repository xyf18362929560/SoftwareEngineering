package nju.express.blservice.impl;

import nju.express.blservice.BItransportblService;
import nju.express.vo.BItransport;

public class BItransportblServiceImpl implements BItransportblService{

	@Override
	public void addBItransport(BItransport bitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBItransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBItransport(int id, BItransport bitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BItransport getBItransport(int id) {
		// TODO Auto-generated method stub
		
		return null;
	}

}
