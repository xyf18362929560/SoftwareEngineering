package nju.express.blservice.impl;

import nju.express.blservice.JobblService;
import nju.express.vo.Job;

public class JobblServiceImpl implements JobblService{

	@Override
	public Job checkJob(int id) {
		// TODO Auto-generated method stub
		return null;
	}
    
}
