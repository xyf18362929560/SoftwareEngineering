package nju.express.vo;

public class Driver {
	private int id;
	private String driver_name;
	private String driver_birthday;
	private String driver_idcard;
	private String driver_phone;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDriver_name() {
		return driver_name;
	}
	public void setDriver_name(String driver_name) {
		this.driver_name = driver_name;
	}
	public String getDriver_birthday() {
		return driver_birthday;
	}
	public void setDriver_birthday(String driver_birthday) {
		this.driver_birthday = driver_birthday;
	}
	public String getDriver_idcard() {
		return driver_idcard;
	}
	public void setDriver_idcard(String driver_idcard) {
		this.driver_idcard = driver_idcard;
	}
	public String getDriver_phone() {
		return driver_phone;
	}
	public void setDriver_phone(String driver_phone) {
		this.driver_phone = driver_phone;
	}
	
}
