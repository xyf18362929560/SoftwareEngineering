package nju.express.blservice.impl;

import nju.express.blservice.DepartmentblService;
import nju.express.vo.Department;

public class DepartmentblServiceImpl implements DepartmentblService{

	@Override
	public void addDepartment(Department department) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDepartment(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updataDepartment(int id, Department department) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Department getDepartment(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
