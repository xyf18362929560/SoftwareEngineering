package nju.express.blservice.impl;

import javax.sound.midi.Receiver;

import nju.express.blservice.ReceiverblService;

public class ReceiverblServiceImpl implements ReceiverblService{

	@Override
	public void createReceiver(String name, String address, String phone) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Receiver checkReceiver() {
		// TODO Auto-generated method stub
		return null;
	}

}
