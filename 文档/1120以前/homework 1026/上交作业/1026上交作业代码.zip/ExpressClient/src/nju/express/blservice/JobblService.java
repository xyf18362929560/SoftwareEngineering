package nju.express.blservice;

import nju.express.vo.Job;

public interface JobblService {
    Job checkJob(int id);
}
