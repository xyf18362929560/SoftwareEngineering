package nju.express.blservice.impl;

import nju.express.blservice.RecipientblService;
import nju.express.vo.Recipient;

public class RecipientblServiceImpl implements RecipientblService{

	@Override
	public void createRecipient(String name, String datetime) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Recipient checkRecipient(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
