package nju.express.blservice.impl;

import nju.express.blservice.PaymentblService;
import nju.express.vo.Payment;

public class PaymentblServiceImpl implements PaymentblService{

	@Override
	public void creatPayment(String datetime, double amount, String name,
			String type) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Payment checkPayment(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double statistics(String starttime, String endtime) {
		// TODO Auto-generated method stub
		return 0;
	}

}
