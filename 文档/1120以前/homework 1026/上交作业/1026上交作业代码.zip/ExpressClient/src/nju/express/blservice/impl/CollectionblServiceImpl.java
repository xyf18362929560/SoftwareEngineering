package nju.express.blservice.impl;

import nju.express.blservice.CollectionblService;
import nju.express.vo.Collection;

public class CollectionblServiceImpl implements CollectionblService{

	@Override
	public void addCollection(Collection collection) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCollection(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCollection(int id, Collection collection) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection getCollection(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
