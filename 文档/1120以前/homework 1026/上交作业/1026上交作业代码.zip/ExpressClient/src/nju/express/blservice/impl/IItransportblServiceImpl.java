package nju.express.blservice.impl;

import nju.express.blservice.IItransportblService;
import nju.express.vo.IItransport;

public class IItransportblServiceImpl implements IItransportblService {

	@Override
	public void addIItransport(IItransport iitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteIItransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateIItransport(int id, IItransport iitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public IItransport getIItransport(int id) {
		// TODO Auto-generated method stub
		return null;
	}


}
