package nju.express.vo;

public class Goods {
	private int id;
	private String goods_name;
	private int goods_num;
	private double goods_weight;
	private int goods_length;
	private int goods_width;
	private int goods_height;
	private String goods_info;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public int getGoods_num() {
		return goods_num;
	}
	public void setGoods_num(int goods_num) {
		this.goods_num = goods_num;
	}
	public double getGoods_weight() {
		return goods_weight;
	}
	public void setGoods_weight(double goods_weight) {
		this.goods_weight = goods_weight;
	}
	public int getGoods_length() {
		return goods_length;
	}
	public void setGoods_length(int goods_length) {
		this.goods_length = goods_length;
	}
	public int getGoods_width() {
		return goods_width;
	}
	public void setGoods_width(int goods_width) {
		this.goods_width = goods_width;
	}
	public int getGoods_height() {
		return goods_height;
	}
	public void setGoods_height(int goods_height) {
		this.goods_height = goods_height;
	}
	public String getGoods_info() {
		return goods_info;
	}
	public void setGoods_info(String goods_info) {
		this.goods_info = goods_info;
	}
}
