package nju.express.dataservice.impl;

import nju.express.dataservice.DriverDataService;
import nju.express.vo.Driver;

public class DriverDataServiceImpl implements DriverDataService{

	@Override
	public void addDriver(Driver driver) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDriver(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDriver(int id, Driver driver) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Driver getDriver(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
