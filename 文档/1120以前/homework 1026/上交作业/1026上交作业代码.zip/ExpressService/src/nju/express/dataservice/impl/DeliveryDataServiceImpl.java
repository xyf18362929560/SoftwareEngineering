package nju.express.dataservice.impl;

import nju.express.dataservice.DeliveryDataService;
import nju.express.vo.Delivery;

public class DeliveryDataServiceImpl implements DeliveryDataService{

	@Override
	public void addDelivery(Delivery delivery) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDelivery(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDelivery(int id, Delivery delivery) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Delivery getDelivery(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
