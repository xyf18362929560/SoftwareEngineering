package nju.express.dataservice.impl;

import nju.express.dataservice.IBtransportDataService;
import nju.express.vo.IBtransport;

public class IBtransportDataServiceImpl implements IBtransportDataService{

	@Override
	public void addIBtransport(IBtransport ibtransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteIBtransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateIBtransport(int id, IBtransport ibtransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public IBtransport getIBtransport(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
