package nju.express.dataservice.impl;

import nju.express.dataservice.CollectionDataService;
import nju.express.vo.Collection;

public class CollectionDataServiceImpl implements CollectionDataService {

	@Override
	public void addCollection(Collection collection) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCollection(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCollection(int id, Collection collection) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Collection getCollection(int id) {
		// TODO Auto-generated method stub
		return null;
	}


}
