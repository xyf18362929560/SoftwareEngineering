package nju.express.dataservice.impl;

import nju.express.dataservice.IItransportDataService;
import nju.express.vo.IItransport;

public class IItransportDataServiceImpl implements IItransportDataService{

	@Override
	public void addIItransport(IItransport iitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteIItransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateIItransport(int id, IItransport iitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public IItransport getIItransport(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
