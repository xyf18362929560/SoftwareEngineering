package nju.express.dataservice.impl;

import nju.express.dataservice.BItransportDataService;
import nju.express.vo.BItransport;

public class BItransportDataServiceImpl implements BItransportDataService{

	@Override
	public void addBItransport(BItransport bitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteBItransport(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBItransport(int id, BItransport bitransport) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BItransport getBItransport(int id) {
		// TODO Auto-generated method stub
		return null;
	}


}
