package nju.express.blservice.impl;

import nju.express.blservice.DeliveryblService;
import nju.express.vo.Delivery;

public class DeliveryblServiceImpl implements DeliveryblService{

	@Override
	public void addDelivery(Delivery delivery) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteDelivery(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateDelivery(int id, Delivery delivery) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Delivery getDelivery(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
