package nju.express.blservice.impl;

import nju.express.blservice.GoodsblService;
import nju.express.vo.Goods;

public class GoodsblServiceImpl implements GoodsblService {

	@Override
	public void addGoods(Goods goods) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteGoods(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateGoods(int id, Goods goods) {
		// TODO Auto-generated method stub

	}

	@Override
	public Goods getGoods(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
