package nju.express.blservice;

public interface StockblService {
	void check(String startTime,String endTime);
	void inventory();
}
