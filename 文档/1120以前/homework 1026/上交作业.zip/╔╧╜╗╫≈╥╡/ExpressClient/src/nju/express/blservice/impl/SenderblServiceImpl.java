package nju.express.blservice.impl;

import nju.express.blservice.SenderblService;
import nju.express.vo.Sender;

public class SenderblServiceImpl implements SenderblService {

	@Override
	public void createSender(String name, String address, String phone) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Sender checkSender(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
