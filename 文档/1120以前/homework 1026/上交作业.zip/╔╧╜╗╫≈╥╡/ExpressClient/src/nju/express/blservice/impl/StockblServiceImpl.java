package nju.express.blservice.impl;

import nju.express.blservice.StockblService;

public class StockblServiceImpl implements StockblService {

	@Override
	public void check(String startTime, String endTime) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void inventory() {
		// TODO Auto-generated method stub
		
	}
    
}
