package nju.express.blservice.impl;

import nju.express.blservice.VehicleblService;
import nju.express.vo.Vehicle;

public class VehicleblServiceImpl implements VehicleblService {

	public void createVehicle(String licence) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeVehicle(int id, String newlicence) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Vehicle getVehicle(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vehicle getVehicle(String lience) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
