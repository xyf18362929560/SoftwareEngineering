package nju.express.ui.manager;

import javax.swing.JPanel;

public class ManagerPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1189347673894279651L;

	/**
	 * Create the panel.
	 */
	public ManagerPanel() {

	}

}
