package nju.express.ui.finance;

import javax.swing.JPanel;

public class PaymentPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5682515611581959821L;

	/**
	 * Create the panel.
	 */
	public PaymentPanel() {

	}

}
