package nju.express.blservice.impl;

import java.util.Vector;

import nju.express.blservice.MyOrderblservice;
import nju.express.vo.MyOrder;

public class MyOrderblserviceImpl  implements MyOrderblservice{

	@Override
	public Vector<MyOrder> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyOrder getById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyOrder add(MyOrder order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MyOrder update(MyOrder order) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Vector<MyOrder> getListBySql(String sql) {
		// TODO Auto-generated method stub
		return null;
	}

}
