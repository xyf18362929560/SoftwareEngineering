package nju.express.ui.finance;

import javax.swing.JPanel;

public class AccountPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4683114088924729514L;

	/**
	 * Create the panel.
	 */
	public AccountPanel() {

	}

}
