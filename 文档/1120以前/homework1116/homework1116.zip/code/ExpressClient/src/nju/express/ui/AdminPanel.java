package nju.express.ui;

import javax.swing.JPanel;

public class AdminPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4669645200342386223L;

	/**
	 * Create the panel.
	 */
	public AdminPanel() {

	}

}
