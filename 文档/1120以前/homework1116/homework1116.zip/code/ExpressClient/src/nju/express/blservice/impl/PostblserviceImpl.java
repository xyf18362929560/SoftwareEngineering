package nju.express.blservice.impl;

import java.rmi.RemoteException;
import java.util.Vector;

import nju.express.blservice.Postblservice;
import nju.express.dataservice.CollectionDataService;
import nju.express.dataservice.GoodsDataService;
import nju.express.dataservice.MyOrderDataService;
import nju.express.dataservice.PostDataService;
import nju.express.dataservice.ReceiverDataService;
import nju.express.dataservice.SenderDataService;
import nju.express.dataservice.UserDataService;
import nju.express.vo.Collection;
import nju.express.vo.MyOrder;
import nju.express.vo.Post;
import nju.express.vo.User;

/**
 * �ļ���ҵ���߼�����
 * 
 * @author ���Ƿ�
 * @time 2015��10��31������1:24:05 <br>
 *       ��Ҫ <br>
 *       postDataService �ļ��������߼� <br>
 *       senderDataService �ļ��������߼�<br>
 *       receiverDataService �ռ��������߼�<br>
 *       goodsDataService ���������߼�<br>
 *       userDataService ְԱ�����߼�<br>
 *       collectionDataService �տ�����߼�
 */
public class PostblserviceImpl implements Postblservice {
	private PostDataService postDataService;
	private SenderDataService senderDataService;
	private ReceiverDataService receiverDataService;
	private GoodsDataService goodsDataService;
	private UserDataService userDataService;
	private CollectionDataService collectionDataService;
	private MyOrderDataService orderDataService;
	/**
	 * @param postDataService
	 *            �ļ��������߼�
	 * @param senderDataService
	 *            �ļ��������߼�
	 * @param receiverDataService
	 *            �ռ��������߼�
	 * @param goodsDataService
	 *            ���������߼�
	 * @param userDataService
	 *            ְԱ�����߼�
	 * @param collectionDataService
	 *            �տ�����߼�
	 */
	public PostblserviceImpl(PostDataService postDataService, SenderDataService senderDataService,
			ReceiverDataService receiverDataService, GoodsDataService goodsDataService, UserDataService userDataService,
			CollectionDataService collectionDataService,MyOrderDataService orderDataService) {

		this.postDataService = postDataService;
		this.senderDataService = senderDataService;
		this.receiverDataService = receiverDataService;
		this.goodsDataService = goodsDataService;
		this.userDataService = userDataService;
		this.collectionDataService = collectionDataService;
		this.orderDataService=orderDataService;
	}

	@Override
	public Vector<Post> getAll() {
		Vector<Post> posts = null;
		try {
			posts = postDataService.getList();
			for (Post post : posts) {
				post.setSender(senderDataService.getById(post.getSender_id_fk()));
				post.setReceiver(receiverDataService.getById(post.getReceiver_id_fk()));
				post.setGoods(goodsDataService.getById(post.getGoods_id_fk()));
				post.setCollection(collectionDataService.getById(post.getCollection_id_fk()));
				Collection collection = post.getCollection();
				collection.setCourier_user(userDataService.getById(collection.getCourier_user_id_fk()));
			}
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		return posts;
	}

	@Override
	public Post getById(int id) {
		Post post = null;
		try {
			post = postDataService.getById(id);
			post.setSender(senderDataService.getById(post.getSender_id_fk()));
			post.setReceiver(receiverDataService.getById(post.getReceiver_id_fk()));
			post.setGoods(goodsDataService.getById(post.getGoods_id_fk()));
			post.setCollection(collectionDataService.getById(post.getCollection_id_fk()));
			Collection collection = post.getCollection();
			collection.setCourier_user(userDataService.getById(collection.getCourier_user_id_fk()));
		} catch (RemoteException e) {
			
			e.printStackTrace();
		}
		return post;
	}

	@Override
	public Post add(Post post) {
		Post result = null;
		try {
			int sender_id_fk = senderDataService.insert(post.getSender());
			int receiver_id_fk = receiverDataService.insert(post.getReceiver());
			int goods_id_fk = goodsDataService.insert(post.getGoods());
			int collection_id_fk = collectionDataService.insert(post.getCollection());
			post.setSender_id_fk(sender_id_fk);
			post.setReceiver_id_fk(receiver_id_fk);
			post.setGoods_id_fk(goods_id_fk);
			post.setCollection_id_fk(collection_id_fk);
			int id = postDataService.insert(post);
			MyOrder order=new MyOrder();
			order.setPost_id_fk(id);
			orderDataService.insert(order);
			result = postDataService.getById(id);
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Post update(Post post) {
		Post result = null;
		try {
			senderDataService.update(post.getSender());
			receiverDataService.update(post.getReceiver());
			goodsDataService.update(post.getGoods());
			collectionDataService.update(post.getCollection());

			int id = postDataService.update(post);
			result = postDataService.getById(id);
		} catch (RemoteException e) {
			
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public Vector<User> getCourier() {
		Vector<User> users = null;
		try {
			users = userDataService.getUserOfJob(2);
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		return users;
	}

	@Override
	public Vector<Post> getListByLike(String columnname, Object value) {
		Vector<Post> posts = null;
		try {
			posts = postDataService.getListByLike(columnname, value);
			for (Post post : posts) {
				post.setSender(senderDataService.getById(post.getSender_id_fk()));
				post.setReceiver(receiverDataService.getById(post.getReceiver_id_fk()));
				post.setGoods(goodsDataService.getById(post.getGoods_id_fk()));
				post.setCollection(collectionDataService.getById(post.getCollection_id_fk()));
				Collection collection = post.getCollection();
				collection.setCourier_user(userDataService.getById(collection.getCourier_user_id_fk()));
			}
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		return posts;
	}

	@Override
	public Vector<Post> getListBySql(String sql) {
		Vector<Post> posts = null;
		try {
			posts = postDataService.getListBySql(sql);
			for (Post post : posts) {
				post.setSender(senderDataService.getById(post.getSender_id_fk()));
				post.setReceiver(receiverDataService.getById(post.getReceiver_id_fk()));
				post.setGoods(goodsDataService.getById(post.getGoods_id_fk()));
				post.setCollection(collectionDataService.getById(post.getCollection_id_fk()));
				Collection collection = post.getCollection();
				collection.setCourier_user(userDataService.getById(collection.getCourier_user_id_fk()));
			}
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		return posts;
	}

	@Override
	public Vector<Post> getListByCondition(String columnname, Object value) {
		Vector<Post> posts = null;
		try {
			posts = postDataService.getListByCondition(columnname, value);
			for (Post post : posts) {
				post.setSender(senderDataService.getById(post.getSender_id_fk()));
				post.setReceiver(receiverDataService.getById(post.getReceiver_id_fk()));
				post.setGoods(goodsDataService.getById(post.getGoods_id_fk()));
				post.setCollection(collectionDataService.getById(post.getCollection_id_fk()));
				Collection collection = post.getCollection();
				collection.setCourier_user(userDataService.getById(collection.getCourier_user_id_fk()));
			}
		} catch (RemoteException e) {

			e.printStackTrace();
		}
		return posts;
	}

	@Override
	public boolean delete(int id) {
		try {
			postDataService.delete(id);

		} catch (RemoteException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
