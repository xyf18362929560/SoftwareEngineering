package nju.express.ui.manager;

import javax.swing.JPanel;

public class UserAndDepartmentManagePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5621865830326635323L;

	/**
	 * Create the panel.
	 */
	public UserAndDepartmentManagePanel() {

	}

}
