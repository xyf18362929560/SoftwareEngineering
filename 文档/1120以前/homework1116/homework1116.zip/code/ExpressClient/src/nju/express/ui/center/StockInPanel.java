package nju.express.ui.center;

import java.util.Vector;

import nju.express.ui.utils.CommonPanel;

public class StockInPanel extends CommonPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -935017859680898906L;

	/**
	 * Create the panel.
	 */
	public StockInPanel() {
		this.setSize(1203, 674);
	}

	@Override
	public Vector<String> getColumns() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTableFace() {
		// TODO Auto-generated method stub

	}

	@Override
	public void setViewDatas() {
		// TODO Auto-generated method stub

	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub

	}

}
