package nju.express.ui.finance;

import javax.swing.JPanel;

public class FinancePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6923231270876654967L;

	/**
	 * Create the panel.
	 */
	public FinancePanel() {

	}

}
