package nju.express.ui.manager;

import javax.swing.JPanel;

public class MakeConstantPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7890871760611769475L;

	/**
	 * Create the panel.
	 */
	public MakeConstantPanel() {

	}

}
