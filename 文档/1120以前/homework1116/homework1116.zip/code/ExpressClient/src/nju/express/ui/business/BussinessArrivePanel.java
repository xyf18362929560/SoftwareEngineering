package nju.express.ui.business;

import javax.swing.JPanel;

public class BussinessArrivePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3903852858814836565L;

	/**
	 * Create the panel.
	 */
	public BussinessArrivePanel() {

	}

}
