package nju.express.ui.center;

import javax.swing.JPanel;

public class StockManagePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8071362053061779548L;

	/**
	 * Create the panel.
	 */
	public StockManagePanel() {

	}

}
