package nju.express.ui.finance;

import javax.swing.JPanel;

public class FinanceInquirePanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public FinanceInquirePanel() {

	}

}
