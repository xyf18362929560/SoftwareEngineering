package nju.express.ui.manager;

import javax.swing.JPanel;

public class DocumentApprovalPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1289813652902597869L;

	/**
	 * Create the panel.
	 */
	public DocumentApprovalPanel() {

	}

}
