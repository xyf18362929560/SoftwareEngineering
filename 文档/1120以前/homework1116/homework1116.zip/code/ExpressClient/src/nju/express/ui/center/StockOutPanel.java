package nju.express.ui.center;

import java.util.Vector;

import nju.express.ui.utils.CommonPanel;

public class StockOutPanel extends CommonPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9090193191458162233L;

	/**
	 * Create the panel.
	 */
	public StockOutPanel() {

	}

	@Override
	public Vector<String> getColumns() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setTableFace() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setViewDatas() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

}
